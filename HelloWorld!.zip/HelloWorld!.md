```python
!pip install gspread oauth2client pandas
```

    Requirement already satisfied: gspread in c:\users\conno\anaconda3\lib\site-packages (6.2.1)
    Requirement already satisfied: oauth2client in c:\users\conno\anaconda3\lib\site-packages (4.1.3)
    Requirement already satisfied: pandas in c:\users\conno\anaconda3\lib\site-packages (2.2.3)
    Requirement already satisfied: google-auth>=1.12.0 in c:\users\conno\anaconda3\lib\site-packages (from gspread) (2.41.1)
    Requirement already satisfied: google-auth-oauthlib>=0.4.1 in c:\users\conno\anaconda3\lib\site-packages (from gspread) (1.2.3)
    Requirement already satisfied: httplib2>=0.9.1 in c:\users\conno\anaconda3\lib\site-packages (from oauth2client) (0.31.0)
    Requirement already satisfied: pyasn1>=0.1.7 in c:\users\conno\anaconda3\lib\site-packages (from oauth2client) (0.4.8)
    Requirement already satisfied: pyasn1-modules>=0.0.5 in c:\users\conno\anaconda3\lib\site-packages (from oauth2client) (0.2.8)
    Requirement already satisfied: rsa>=3.1.4 in c:\users\conno\anaconda3\lib\site-packages (from oauth2client) (4.9.1)
    Requirement already satisfied: six>=1.6.1 in c:\users\conno\anaconda3\lib\site-packages (from oauth2client) (1.17.0)
    Requirement already satisfied: numpy>=1.26.0 in c:\users\conno\anaconda3\lib\site-packages (from pandas) (2.1.3)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\conno\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\conno\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\conno\anaconda3\lib\site-packages (from pandas) (2025.2)
    Requirement already satisfied: cachetools<7.0,>=2.0.0 in c:\users\conno\anaconda3\lib\site-packages (from google-auth>=1.12.0->gspread) (5.5.1)
    Requirement already satisfied: requests-oauthlib>=0.7.0 in c:\users\conno\anaconda3\lib\site-packages (from google-auth-oauthlib>=0.4.1->gspread) (2.0.0)
    Requirement already satisfied: pyparsing<4,>=3.0.4 in c:\users\conno\anaconda3\lib\site-packages (from httplib2>=0.9.1->oauth2client) (3.2.0)
    Requirement already satisfied: oauthlib>=3.0.0 in c:\users\conno\anaconda3\lib\site-packages (from requests-oauthlib>=0.7.0->google-auth-oauthlib>=0.4.1->gspread) (3.3.1)
    Requirement already satisfied: requests>=2.0.0 in c:\users\conno\anaconda3\lib\site-packages (from requests-oauthlib>=0.7.0->google-auth-oauthlib>=0.4.1->gspread) (2.32.3)
    Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\conno\anaconda3\lib\site-packages (from requests>=2.0.0->requests-oauthlib>=0.7.0->google-auth-oauthlib>=0.4.1->gspread) (3.3.2)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\conno\anaconda3\lib\site-packages (from requests>=2.0.0->requests-oauthlib>=0.7.0->google-auth-oauthlib>=0.4.1->gspread) (3.7)
    Requirement already satisfied: urllib3<3,>=1.21.1 in c:\users\conno\anaconda3\lib\site-packages (from requests>=2.0.0->requests-oauthlib>=0.7.0->google-auth-oauthlib>=0.4.1->gspread) (2.3.0)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\conno\anaconda3\lib\site-packages (from requests>=2.0.0->requests-oauthlib>=0.7.0->google-auth-oauthlib>=0.4.1->gspread) (2025.10.5)
    


```python
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd
print("✅ Imports worked!")
```

    ✅ Imports worked!
    


```python
scope = [
    "https://spreadsheets.google.com/feeds",
    "https://www.googleapis.com/auth/drive"
]
creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
client = gspread.authorize(creds)

sheet = client.open("Copy of Civilian Unemployment Rate 2005 - 2025").sheet1  # use your exact sheet name
data = sheet.get_all_records()

import pandas as pd
df = pd.DataFrame(data)
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4.9</td>
    </tr>
  </tbody>
</table>
</div>




```python
import os
print(os.getcwd())
```

    C:\Users\Conno\Google_Sheets_Project
    


```python
df.to_csv("unemployment_data.csv", index=False)

print("✅ CSV file created!")

```

    ✅ CSV file created!
    


```python
import pandas as pd
df = pd.read_csv('unemployment_data.csv')
df.info()

df.plot()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 241 entries, 0 to 240
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   Month   241 non-null    object 
     1   Total   241 non-null    float64
    dtypes: float64(1), object(1)
    memory usage: 3.9+ KB
    




    <Axes: >




    
![png](output_5_2.png)
    



```python
msk = (df.index < len(df)-30)
df_train = df[msk].copy()
df_test = df[~msk].copy()
```


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
```


```python
ts = df['Total']
```


```python

ts = pd.to_numeric(ts, errors='coerce')

ts = ts.replace([np.inf, -np.inf], np.nan).dropna()

ts = ts.reset_index(drop=True)

print(f"Number of valid observations: {len(ts)}")
print(ts.head())
```


```python
if len(ts) < 10:
    raise ValueError("Time series too short for ACF/PACF plotting.")
```


```python
max_lags = min(40, len(ts)//2)

plot_acf(ts, lags=max_lags)
plt.show()

plot_pacf(ts, lags=max_lags, method='ywm') 
plt.show()

```


    
![png](output_11_0.png)
    



    
![png](output_11_1.png)
    



```python
ts = df['Total']
```


```python
ts = pd.to_numeric(ts, errors='coerce')  
ts = ts.replace([np.inf, -np.inf], np.nan) 
ts = ts.dropna()                             
ts = ts.reset_index(drop=True)
```


```python
from statsmodels.tsa.stattools import adfuller

adf_test = adfuller(ts)
print(f'p-value: {adf_test[1]}')
```

    p-value: 0.0877781756537831
    


```python
df_diff = df.diff().dropna()
df_diff.plot()
```




    <Axes: >




    
![png](output_15_1.png)
    



```python
acf_diff = plot_acf(df_diff)
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[3], line 1
    ----> 1 acf_diff = plot_acf(df_diff)
    

    NameError: name 'plot_acf' is not defined



```python
adf_test = adfuller(df_diff)
print(f'p-value: {adf_test[1]}')
```

    p-value: 1.6920406090287417e-22
    


```python
from statsmodels.tsa.arima.model import ARIMA
model = ARIMA(df, order=(2,1,0))
model_fit = model.fit()
print(model_fit.summary())
```

                                   SARIMAX Results                                
    ==============================================================================
    Dep. Variable:                  Total   No. Observations:                  241
    Model:                 ARIMA(2, 1, 0)   Log Likelihood                -263.131
    Date:                Wed, 12 Nov 2025   AIC                            532.261
    Time:                        20:02:13   BIC                            542.703
    Sample:                             0   HQIC                           536.469
                                    - 241                                         
    Covariance Type:                  opg                                         
    ==============================================================================
                     coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------
    ar.L1          0.0236      0.029      0.828      0.408      -0.032       0.080
    ar.L2         -0.1220      0.049     -2.487      0.013      -0.218      -0.026
    sigma2         0.5245      0.006     91.298      0.000       0.513       0.536
    ===================================================================================
    Ljung-Box (L1) (Q):                   0.00   Jarque-Bera (JB):            303601.64
    Prob(Q):                              0.98   Prob(JB):                         0.00
    Heteroskedasticity (H):              34.73   Skew:                            12.05
    Prob(H) (two-sided):                  0.00   Kurtosis:                       175.57
    ===================================================================================
    
    Warnings:
    [1] Covariance matrix calculated using the outer product of gradients (complex-step).
    


```python
import matplotlib.pyplot as plt
residuals = model_fit.resid[1:]
fig, ax = plt.subplots(1,2)
residuals.plot(title= 'Residuals' , ax=ax[0])
residuals.plot(title= 'Density' , kind='kde', ax=ax[1])
plt.show()
```


    
![png](output_19_0.png)
    



```python
forecast_test = model_fit.forecast(len(df))

df['forecast_manual'] = [None]*len(df) + list(forecast_test)

df.plot()
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[63], line 3
          1 forecast_test = model_fit.forecast(len(df))
    ----> 3 df['forecast_manual'] = [None]*len(df) + list(forecast_test)
          5 df.plot()
    

    File ~\anaconda3\Lib\site-packages\pandas\core\frame.py:4311, in DataFrame.__setitem__(self, key, value)
       4308     self._setitem_array([key], value)
       4309 else:
       4310     # set column
    -> 4311     self._set_item(key, value)
    

    File ~\anaconda3\Lib\site-packages\pandas\core\frame.py:4524, in DataFrame._set_item(self, key, value)
       4514 def _set_item(self, key, value) -> None:
       4515     """
       4516     Add series to DataFrame in specified column.
       4517 
       (...)
       4522     ensure homogeneity.
       4523     """
    -> 4524     value, refs = self._sanitize_column(value)
       4526     if (
       4527         key in self.columns
       4528         and value.ndim == 1
       4529         and not isinstance(value.dtype, ExtensionDtype)
       4530     ):
       4531         # broadcast across multiple columns if necessary
       4532         if not self.columns.is_unique or isinstance(self.columns, MultiIndex):
    

    File ~\anaconda3\Lib\site-packages\pandas\core\frame.py:5266, in DataFrame._sanitize_column(self, value)
       5263     return _reindex_for_setitem(value, self.index)
       5265 if is_list_like(value):
    -> 5266     com.require_length_match(value, self.index)
       5267 arr = sanitize_array(value, self.index, copy=True, allow_2d=True)
       5268 if (
       5269     isinstance(value, Index)
       5270     and value.dtype == "object"
       (...)
       5273     # TODO: Remove kludge in sanitize_array for string mode when enforcing
       5274     # this deprecation
    

    File ~\anaconda3\Lib\site-packages\pandas\core\common.py:573, in require_length_match(data, index)
        569 """
        570 Check the length of data matches the length of the index.
        571 """
        572 if len(data) != len(index):
    --> 573     raise ValueError(
        574         "Length of values "
        575         f"({len(data)}) "
        576         "does not match length of index "
        577         f"({len(index)})"
        578     )
    

    ValueError: Length of values (482) does not match length of index (241)



```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
forecast_test = forecast_test 

numeric_cols = df.select_dtypes(include=[np.number]).columns
if len(numeric_cols) == 0:
    raise ValueError("No numeric columns found in DataFrame.")
actual_col = numeric_cols[0] 
print(f"Using numeric column '{actual_col}' for plotting and forecasting.")

ts = pd.to_numeric(df[actual_col], errors='coerce')
ts = ts.replace([np.inf, -np.inf], np.nan).dropna()
if len(ts) == 0:
    raise ValueError(f"No valid numeric data in column '{actual_col}' after cleaning.")

df['forecast_manual'] = np.nan

forecast_len = len(forecast_test)
if forecast_len > len(df):
    extra_len = forecast_len - len(df)
    extra_index = pd.RangeIndex(start=df.index[-1]+1, stop=df.index[-1]+1+extra_len)
    extra_df = pd.DataFrame({actual_col: [np.nan]*extra_len, 'forecast_manual': forecast_test[-extra_len:]}, index=extra_index)
    df = pd.concat([df, extra_df])
    df.iloc[-forecast_len:, df.columns.get_loc('forecast_manual')] = forecast_test
else:
    df.iloc[-forecast_len:, df.columns.get_loc('forecast_manual')] = forecast_test

plt.figure(figsize=(12,6))
plt.plot(df.index, df[actual_col], label='Actual')
plt.plot(df.index, df['forecast_manual'], label='Forecast', linestyle='--')
plt.xlabel('Time')
plt.ylabel(actual_col)
plt.title(f'Actual vs Forecast for {actual_col}')
plt.legend()
plt.show()

```

    Using numeric column 'Total' for plotting and forecasting.
    


    
![png](output_21_1.png)
    



```python
import pmdarima as pm
auto_arima = pm.auto_arima(df, stepwise=False, seasonal=False)
auto_arima
```


```python

```
